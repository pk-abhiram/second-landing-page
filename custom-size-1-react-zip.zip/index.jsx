import React from 'react';

function App() {
  return <CustomSize1 {...customSize1Data} />;
}

export default App;

function CustomSize1(props) {
  const {
    overlapGroup,
    nightSky,
    polygon1,
    path6,
    number,
    text1,
    title,
    x002Instagram,
    path8,
    path9,
    path10,
    path11,
  } = props;

  return (
    <div className="custom-size-1">
      <div className="overlap-group" style={{ backgroundImage: `url(${overlapGroup})` }}>
        <div className="flex-col">
          <div className="group-3">
            <div className="night-sky">{nightSky}</div>
            <div className="overlap-group1">
              <img className="polygon-1" src={polygon1} />
              <img className="path-6" src={path6} />
            </div>
          </div>
          <div className="group-2">
            <div className="overlap-group2">
              <div className="number">{number}</div>
              <div className="text-1">{text1}</div>
            </div>
          </div>
        </div>
        <h1 className="title">{title}</h1>
        <div className="x002-instagram" style={{ backgroundImage: `url(${x002Instagram})` }}>
          <div className="overlap-group3">
            <img className="path-8" src={path8} />
            <img className="path-9" src={path9} />
          </div>
        </div>
        <img className="path-10" src={path10} />
        <img className="path-11" src={path11} />
      </div>
    </div>
  );
}

const customSize1Data = {
    overlapGroup: "https://anima-uploads.s3.amazonaws.com/projects/607d1fb9d0577f10c97be4db/releases/607d36688a6cacdb7f465217/img/landing-bg@1x.png",
    nightSky: "Night Sky",
    polygon1: "https://anima-uploads.s3.amazonaws.com/projects/607d1fb9d0577f10c97be4db/releases/607d36688a6cacdb7f465217/img/polygon-1@1x.png",
    path6: "https://anima-uploads.s3.amazonaws.com/projects/607d1fb9d0577f10c97be4db/releases/607d36688a6cacdb7f465217/img/path-6@1x.png",
    number: "17",
    text1: "/04",
    title: "Travel",
    x002Instagram: "https://anima-uploads.s3.amazonaws.com/projects/607d1fb9d0577f10c97be4db/releases/607d36688a6cacdb7f465217/img/path-7@1x.png",
    path8: "https://anima-uploads.s3.amazonaws.com/projects/607d1fb9d0577f10c97be4db/releases/607d36688a6cacdb7f465217/img/path-8@1x.png",
    path9: "https://anima-uploads.s3.amazonaws.com/projects/607d1fb9d0577f10c97be4db/releases/607d36688a6cacdb7f465217/img/path-9@1x.png",
    path10: "https://anima-uploads.s3.amazonaws.com/projects/607d1fb9d0577f10c97be4db/releases/607d36688a6cacdb7f465217/img/path-10@1x.png",
    path11: "https://anima-uploads.s3.amazonaws.com/projects/607d1fb9d0577f10c97be4db/releases/607d36688a6cacdb7f465217/img/path-11@1x.png",
};

